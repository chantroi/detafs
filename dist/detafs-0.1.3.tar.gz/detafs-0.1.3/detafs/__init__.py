from .core import DetaPathLike

__all__ = ['DetaPathLike']